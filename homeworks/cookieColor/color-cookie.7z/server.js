const express = require("express");
const cookieParser = require("cookie-parser");
const hbs = require("hbs");
const app = express();
app.set("view engine", "hbs");
app.use(cookieParser());
app.use(
  express.urlencoded({
    extended: false
  })
);
app.use(express.static(__dirname + "/public"));

app.get("/", (req, res) => {
  let color = req.cookies.color;
  res.render("home.hbs", {color});
});
app.post("/", (req, res) => {
  res.cookie("color", req.body.color);
  let color = req.body.color;
  res.render("home.hbs", {color});
});

app.listen(3000, () => {
  console.log("Server is up on port 3000");
});
