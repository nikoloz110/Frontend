// open this url first: http://localhost:3000/product/1
const express = require("express");
const hbs = require("hbs");
const cookieParser = require("cookie-parser");
const session = require("express-session");
const bodyParser = require("body-parser");

const app = express();

app.use(cookieParser());
app.use(
  session({
    secret: "super cat",
    name: "demo-site",
    resave: true,
    saveUninitialized: false
  })
);
app.use(
  bodyParser.urlencoded({
    extended: false
  })
);
app.use(express.static("public"));
hbs.registerPartials(__dirname + "/views/partials");
app.set("view engine", "hbs");
hbs.registerHelper("screamIt", text => {
  return text.toUpperCase();
});
hbs.registerHelper("multiply", (num1, num2) => {
  return num1 * num2;
});
hbs.registerHelper("addition", (num1, num2, num3) => {
  return num1 + num2 + num3;
});
const products = [
  {
    id: 1,
    name: "Graphics Card",
    image: "/images/card.png",
    price: 299,
    description: "Nvidia GeForce RTX 2080 Ti"
  },
  {
    id: 2,
    name: "HDMI Cable",
    image: "/images/cable.jpg",
    price: 8.99,
    description: "Mediabridge Ultra Series"
  },
  {
    id: 3,
    name: "SSD Drive",
    image: "/images/ssd.jpg",
    price: 95.96,
    description: "Kingston SSD 480GB SATA 3 2.5"
  }
];

app.get("/product/:id", (req, res) => {
  product = products.find(product => product.id === parseInt(req.params.id));

  res.render("home.hbs", {
    id: product.id,
    name: product.name,
    image: product.image,
    price: product.price,
    description: product.description
  });
  
});
app.post("/summary", (req, res)=>{
  res.render("summary.hbs", {
    graphicsQuantity: req.session.graphicsQuantity || 0,
    hdmiQuantity: req.session.hdmiQuantity || 0,
    ssdQuantity: req.session.ssdQuantity || 0,
    prodName1: "Graphics Card",
    prodName2: "HDMI Cable",
    prodName3: "SSD Drive",
    price1: 299,
    price2: 8.99,
    price3: 95.96,
  });
});
app.post("/", (req, res) => {
  if (req.body.id == 1) {
    if (req.session.graphicsQuantity) {
      req.session.graphicsQuantity += Number(req.body.quantity);
    } else {
      req.session.graphicsQuantity = Number(req.body.quantity);
    }
  } else if (req.body.id == 2) {
    if (req.session.hdmiQuantity) {
      req.session.hdmiQuantity += Number(req.body.quantity);
    } else {
      req.session.hdmiQuantity = Number(req.body.quantity);
    }
  } else if (req.body.id == 3) {
    if (req.session.ssdQuantity) {
      req.session.ssdQuantity += Number(req.body.quantity);
    } else {
      req.session.ssdQuantity = Number(req.body.quantity);
    }
  }

  product = products.find(product => product.id === parseInt(req.body.id));

  res.render("home.hbs", {
    id: product.id,
    name: product.name,
    image: product.image,
    price: product.price,
    description: product.description
  });
});

app.listen(3000, () => {
  console.log("Server is up on port 3000");
});


// open this url first: http://localhost:3000/product/1